import React, { useState, useEffect } from "react";
import Layout from "../components/Layout";

// Imports iconos
import MembersIcon from "../assets/members.png";
import Admin from "../assets/admin.png";
import DeleteUser from "../assets/deleteuser.png";

function Members({ contract, account }) {
  const [members, setMembers] = useState([]);
  const [status, setStatus] = useState("");
  const [isMining, setIsMining] = useState(false);
  const [chairperson, setChairperson] = useState("");

  useEffect(() => {
    async function fetchData() {
      try {
        const count = await contract.methods.countMembers().call();
        const loaded = [];

        for (let i = 0; i < count; i++) {
          const member = await contract.methods.memberList(i).call();
          loaded.push(member);
        }

        const chair = await contract.methods.chairperson().call();
        setChairperson(chair);
        setMembers(loaded);
      } catch (error) {
        console.error("Error cargando miembros:", error);
      }
    }

    fetchData();
  }, [contract]);

  const handleRemove = async (address) => {
    if (!window.web3.utils.isAddress(address)) {
      setStatus("❌ Dirección inválida.");
      return;
    }

    try {
      setIsMining(true);
      setStatus(`⛏️ Eliminando miembro ${address}...`);

      await contract.methods.removeMember(address).send({
        from: account,
        gas: 100000,
        gasPrice: "0",
      });

      setStatus(`✅ Miembro ${address} eliminado.`);
      setMembers((prev) => prev.filter((addr) => addr !== address));
    } catch (error) {
      console.error(error);
      setStatus("❌ Error al eliminar miembro.");
    } finally {
      setIsMining(false);
    }
  };

  const isChairperson =
    account?.toLowerCase() === chairperson?.toLowerCase();

  return (
    <Layout>
      <h2 style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <img
          src={MembersIcon}
          alt="Miembros"
          style={{ width: "40px", height: "40px", verticalAlign: "middle" }}
        />
        Miembros actuales
      </h2>

      {members.length === 0 ? (
        <p>No hay miembros registrados.</p>
      ) : (
        <ul style={{ listStyle: "none", paddingLeft: 0 }}>
          {members.map((addr, idx) => (
            <li
              key={idx}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "0.75rem 0",
                borderBottom: "1px solid #eee",
              }}
            >
              {/* Dirección alineada a la izquierda con espacio a la derecha */}
              <div
                style={{
                  flex: 1,
                  wordBreak: "break-all",
                  marginRight: "2rem", // Espacio entre dirección e iconos
                }}
              >
                {addr}
              </div>

              {/* Iconos alineados a la derecha */}
              <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                {addr.toLowerCase() === chairperson?.toLowerCase() && (
                  <img
                    src={Admin}
                    alt="Admin"
                    title="Chairperson"
                    style={{ width: "30px", height: "30px" }}
                  />
                )}

                {isChairperson && addr.toLowerCase() !== chairperson?.toLowerCase() && (
                  <button
                    style={{
                      background: "transparent",
                      border: "none",
                      cursor: isMining ? "not-allowed" : "pointer",
                      padding: 0,
                    }}
                    onClick={() => handleRemove(addr)}
                    disabled={isMining}
                    title="Eliminar miembro"
                  >
                    <img
                      src={DeleteUser}
                      alt="Eliminar"
                      style={{ width: "30px", height: "30px" }}
                    />
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}

      {status && (
        <p style={{ marginTop: "1rem", fontWeight: "bold" }}>{status}</p>
      )}
    </Layout>
  );
}

export default Members;